INSERT INTO GREETINGS(name) values ('Docker');
